package service;

public class Util
{
	public boolean isFinder(String str)
	{

		int right = 0;
		int left = str.length() - 1;
		int half = left / 2;

		for (int i = 0; i < half; i++, right++, left--)
		{
			if (str.charAt(right) != str.charAt(left))
				return false;
		}
		return true;
	}

}
